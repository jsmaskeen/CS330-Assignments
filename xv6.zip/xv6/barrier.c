/*----------xv6 sync lab----------*/
#include "types.h"
#include "arm.h"
#include "spinlock.h"
#include "defs.h"
#include "barrier.h"

//define any variables needed here

int
barrier_init(int n)
{
  //to be done
  return 0;
}

int
barrier_check(void)
{
  //to be done
  return 0;
}

/*----------xv6 sync lock end----------*/
